R4 SHOPPING STORE — Website Folder
==================================
Folder ki files:
  index.html        -> Customer website (isay open karein)
  admin.html        -> OWNER PANEL (sirf aapke liye, ek hi file)
  js/data.js        -> Products + settings (WhatsApp number yahan hai)
  js/store.js, css/style.css, images/  -> website ki baqi files

WhatsApp number: 0333 2253354 (92 333 2253354) — Store Settings se change ho sakta hai.

OWNER PANEL KAISE USE KAREIN
1. admin.html open karein. First password:  r4admin   (Settings mein change karein)
2. Products tab: Add New Product / Edit / Delete / Copy / upar-neeche karein.
   Photo phone ya computer se upload karein. Price, category, description, features, "Sold out" sab edit hota hai.
3. Store Settings: WhatsApp number, delivery charges, announcement bar.
4. Publish / Backup tab -> "Download data.js" -> is file se js/data.js REPLACE karein -> folder dobara upload karein.

ORDER KAISE AATA HAI
Customer Add to Cart -> naam, phone, shehar, poora address -> "Contact with WhatsApp"
-> aapke WhatsApp par poora order (items, total, address) message ban kar aa jata hai.
Customer ka address uske device par save rehta hai (agli baar dobara nahi likhna parta).

HOSTING (free): Netlify Drop (app.netlify.com/drop) par poora folder drag-drop karein.
SECURITY: admin.html ko public hosting par upload na karein — apne paas rakhein.
