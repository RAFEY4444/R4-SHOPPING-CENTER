/* R4 SHOPPING STORE — STORE DATA
   Is file ko admin.html se "Download data.js" kar ke replace karein. */
window.R4_DEFAULT = {
  "updated": 2,
  "settings": {
    "storeName": "R4 SHOPPING STORE",
    "tagline": "Shop More • Pay Less",
    "whatsapp": "923332253354",
    "displayPhone": "0333 2253354",
    "currency": "Rs",
    "delivery": 200,
    "freeDeliveryAbove": 0,
    "announcement": "🚚 Delivery all over Pakistan  •  💵 Cash on Delivery  •  ✨ New products added every week"
  },
  "products": [
    {
      "id": "p1",
      "name": "Dancing Cactus Talking Toy",
      "category": "Kids & Toys",
      "price": 999,
      "oldPrice": 0,
      "badge": "Best Seller",
      "inStock": true,
      "image": "images/cactus.jpg",
      "desc": "Bachon ka favourite! Ye pyara cactus aapki awaz ko repeat karta hai, gaane gaata hai aur colourful lights ke saath dance karta hai. Kids ke liye perfect gift.",
      "features": [
        "Sing, talk & dance",
        "Repeats what you say",
        "Colourful LED lights",
        "Comes in gift box",
        "Perfect gift for kids"
      ]
    },
    {
      "id": "p2",
      "name": "Reversible Octopus Plush (7 inch)",
      "category": "Kids & Toys",
      "price": 499,
      "oldPrice": 0,
      "badge": "Trending",
      "inStock": true,
      "image": "images/octopus.jpg",
      "desc": "Flip karein aur mood badlein! Ye soft reversible octopus ek side se khush aur doosri side se naraz dikhta hai. Super soft plush, 7 inch size, kai colours mein.",
      "features": [
        "2 moods, 1 octopus – flip it!",
        "7 inch perfect size",
        "Super soft & plush",
        "Premium quality material",
        "Multiple colours available"
      ]
    },
    {
      "id": "p3",
      "name": "Rainbow Magic Spring (Slinky)",
      "category": "Kids & Toys",
      "price": 140,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/slinky.jpg",
      "desc": "Rangeen rainbow magic spring jo seedhiyon par chalta hai aur haath se haath mein jhoolta hai. Bachon ke liye sasta aur mazedar toy.",
      "features": [
        "Rainbow colours",
        "Plastic – light & durable",
        "Walks down stairs",
        "Fun for all ages"
      ]
    },
    {
      "id": "p4",
      "name": "Manual Speedy Chopper",
      "category": "Kitchen & Home",
      "price": 699,
      "oldPrice": 0,
      "badge": "Kitchen Hero",
      "inStock": true,
      "image": "images/chopper.jpg",
      "desc": "Pyaz, lehsan, sabziyan aur gosht — sab kuch seconds mein chop karein, bina bijli ke. Sirf dori kheenchein aur kaam khatam. Easy to clean.",
      "features": [
        "Manual pull-cord – no electricity",
        "Chops veggies, garlic, onion & meat",
        "Sharp stainless blades",
        "Clear bowl with lid",
        "Easy to wash"
      ]
    },
    {
      "id": "p5",
      "name": "Water Pump for 19 Litre Can",
      "category": "Kitchen & Home",
      "price": 499,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/waterpump.jpg",
      "desc": "19 litre ki bottle ko uthane ki zaroorat nahi — bas pump lagayein aur press kar ke pani nikalein. Fits standard 19L water cans.",
      "features": [
        "Fits 19 litre cans",
        "Easy manual press pump",
        "No electricity needed",
        "Hygienic & spill free"
      ]
    },
    {
      "id": "p6",
      "name": "Wooden Umrah Saving Box",
      "category": "Gifts & Home",
      "price": 430,
      "oldPrice": 0,
      "badge": "Gift Idea",
      "inStock": true,
      "image": "images/umrahbox.jpg",
      "desc": "Umrah ka khwab poora karne ke liye roz thori thori saving karein. Wooden box par amount grid bana hua hai — note daalein aur target ki taraf barhein. Disassemble design.",
      "features": [
        "Wooden finish",
        "Amount grid on the box",
        "Disassemble design",
        "Great gift for family",
        "Helps build saving habit"
      ]
    },
    {
      "id": "p7",
      "name": "USB Rechargeable Bike Headlight",
      "category": "Bike & Outdoor",
      "price": 199,
      "oldPrice": 0,
      "badge": "Super Sale",
      "inStock": true,
      "image": "images/headlight.jpg",
      "desc": "Raat ki ride ab safe. Tez LED headlight ke saath loud horn, USB se charge hota hai. Cycle aur bike dono par lagta hai.",
      "features": [
        "400 LM bright light",
        "1200 mAh rechargeable battery",
        "120 dB speaker / horn",
        "IPX6 water resistant",
        "3 flash modes • 5 sound modes",
        "USB charging"
      ]
    },
    {
      "id": "p8",
      "name": "Adjustable Hand Gripper (5–60 kg)",
      "category": "Fitness",
      "price": 299,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/gripper.jpg",
      "desc": "Hath aur kalai ko mazboot banayein. Adjustable resistance 5 se 60 kg tak, built-in counter aur non-slip rubber grip ke saath.",
      "features": [
        "Load adjustable 5–60 kg",
        "Built-in counter",
        "Soft non-slip rubber grip",
        "Strong spring"
      ]
    },
    {
      "id": "p9",
      "name": "Slim Soft Leather Wallet",
      "category": "Bags & Fashion",
      "price": 359,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/wallet.jpg",
      "desc": "Slim, soft aur stylish wallet jo jeb mein aaram se aa jaye. Cards aur cash ke liye kaafi jagah.",
      "features": [
        "Slim fashionable design",
        "Soft leather feel",
        "Card & cash slots",
        "Pocket friendly"
      ]
    },
    {
      "id": "p10",
      "name": "Premium Quality School Bag",
      "category": "Bags & Fashion",
      "price": 649,
      "oldPrice": 0,
      "badge": "New",
      "inStock": true,
      "image": "images/schoolbag.jpg",
      "desc": "Mazboot aur spacious school / college bag. Kai pockets, comfortable straps aur long-lasting stitching.",
      "features": [
        "Spacious main compartment",
        "Multiple pockets",
        "Padded comfortable straps",
        "Strong stitching & zippers",
        "Black premium look"
      ]
    },
    {
      "oldPrice": 0,
      "inStock": true,
      "id": "p11",
      "name": "Jumbo Slime Kit – 12 Slimes + 6 Glitter Bottles",
      "category": "Kids & Toys",
      "price": 399,
      "badge": "Kids Favourite",
      "image": "images/slime399.jpg",
      "desc": "12 rangeen slime tubs, 6 glitter bottles, foam beads, orbez ball aur water balloons — bachon ke liye poora creative slime set.",
      "features": [
        "12 colourful slime pots",
        "6 glitter bottles",
        "Foam beads & charms included",
        "Orbez ball + water balloons",
        "Gift-ready jumbo box"
      ]
    },
    {
      "oldPrice": 0,
      "inStock": true,
      "id": "p12",
      "name": "Jumbo Slime Kit Deluxe (12 Slimes + Extras)",
      "category": "Kids & Toys",
      "price": 499,
      "badge": "Deluxe",
      "image": "images/slime499.jpg",
      "desc": "Deluxe jumbo slime kit: 12 slimes, 6 glitter bottles, water balloons, orbez balls aur bohat se extras. Safe, easy aur mazedar (age 6+).",
      "features": [
        "12 slime pots in bright colours",
        "6 glitter bottles",
        "Water balloons & orbez balls",
        "Extra beads, charms & tools",
        "Safe & easy fun • Age 6+"
      ]
    },
    {
      "id": "p13",
      "name": "Wireless Bluetooth Earbuds",
      "category": "Electronics",
      "price": 1299,
      "oldPrice": 0,
      "badge": "Trending",
      "inStock": true,
      "image": "images/earbuds.jpg",
      "placeholder": true,
      "desc": "Clear sound aur deep bass, touch controls aur charging case ke saath. Calls aur music dono ke liye.",
      "features": [
        "Bluetooth wireless",
        "Charging case",
        "Touch controls",
        "Built-in mic"
      ]
    },
    {
      "id": "p14",
      "name": "Smart Watch (Calls + Fitness)",
      "category": "Electronics",
      "price": 1799,
      "oldPrice": 0,
      "badge": "Hot",
      "inStock": true,
      "image": "images/smartwatch.jpg",
      "placeholder": true,
      "desc": "Stylish smart watch: notifications, heart-rate aur steps tracking. Phone se connect karein.",
      "features": [
        "Bluetooth calling",
        "Heart-rate & steps",
        "Multiple watch faces",
        "Rechargeable"
      ]
    },
    {
      "id": "p15",
      "name": "LED Ring Light with Stand",
      "category": "Electronics",
      "price": 899,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/ringlight.jpg",
      "placeholder": true,
      "desc": "TikTok, reels aur photos ke liye perfect lighting. 3 light modes aur adjustable stand.",
      "features": [
        "3 colour modes",
        "Adjustable stand",
        "Phone holder",
        "USB powered"
      ]
    },
    {
      "id": "p16",
      "name": "Car Mobile Holder",
      "category": "Mobile Accessories",
      "price": 349,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/carholder.jpg",
      "placeholder": true,
      "desc": "Gaari mein mobile ko mazbooti se pakarta hai. 360° rotation aur easy fit.",
      "features": [
        "360° rotation",
        "Strong grip",
        "Fits all phones",
        "Easy to install"
      ]
    },
    {
      "id": "p17",
      "name": "Power Bank 10000mAh",
      "category": "Mobile Accessories",
      "price": 1599,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/powerbank.jpg",
      "placeholder": true,
      "desc": "Safar mein charging ki fikr khatam. Fast charging aur dual USB ports.",
      "features": [
        "10000 mAh",
        "Dual USB output",
        "LED indicator",
        "Compact & portable"
      ]
    },
    {
      "id": "p18",
      "name": "Portable Bluetooth Speaker",
      "category": "Electronics",
      "price": 999,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/speaker.jpg",
      "placeholder": true,
      "desc": "Chota speaker, bari awaz. Bluetooth, USB aur memory card support.",
      "features": [
        "Powerful bass",
        "Bluetooth 5.0",
        "Rechargeable",
        "FM / USB / TF card"
      ]
    },
    {
      "id": "p19",
      "name": "Hair Straightener Brush",
      "category": "Beauty & Care",
      "price": 1499,
      "oldPrice": 0,
      "badge": "New",
      "inStock": true,
      "image": "images/straightener.jpg",
      "placeholder": true,
      "desc": "Ek hi brush se hair seedhe karein, jaldi garam hota hai. Anti-scald design.",
      "features": [
        "Fast heating",
        "Anti-scald comb",
        "Temperature control",
        "Easy styling"
      ]
    },
    {
      "id": "p20",
      "name": "Rechargeable Hair & Beard Trimmer",
      "category": "Beauty & Care",
      "price": 1199,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/trimmer.jpg",
      "placeholder": true,
      "desc": "Cordless trimmer: sharp blades, USB charging aur multiple guard combs.",
      "features": [
        "Cordless & rechargeable",
        "Sharp steel blades",
        "Guard combs included",
        "USB charging"
      ]
    },
    {
      "id": "p21",
      "name": "Stainless Steel Water Bottle",
      "category": "Kitchen & Home",
      "price": 649,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/bottle.jpg",
      "placeholder": true,
      "desc": "Pani ghanton thanda ya garam rakhne wali leak-proof bottle.",
      "features": [
        "Double wall insulation",
        "Leak-proof lid",
        "BPA free",
        "Easy carry"
      ]
    },
    {
      "id": "p22",
      "name": "LED Strip Lights (RGB)",
      "category": "Home & Gifts",
      "price": 499,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/ledstrip.jpg",
      "placeholder": true,
      "desc": "Room ko cinematic look dein. Remote ke saath kai colours aur effects.",
      "features": [
        "RGB colours",
        "Remote control",
        "Self-adhesive",
        "USB powered"
      ]
    },
    {
      "id": "p23",
      "name": "Stylish UV Sunglasses",
      "category": "Bags & Fashion",
      "price": 399,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/sunglasses.jpg",
      "placeholder": true,
      "desc": "Trendy frame, UV protection. Daily wear aur summer ke liye.",
      "features": [
        "UV protection",
        "Lightweight frame",
        "Unisex style"
      ]
    },
    {
      "id": "p24",
      "name": "Ladies Fashion Handbag",
      "category": "Bags & Fashion",
      "price": 899,
      "oldPrice": 0,
      "badge": "New",
      "inStock": true,
      "image": "images/handbag.jpg",
      "placeholder": true,
      "desc": "Elegant handbag jo har outfit ke saath match kare. Spacious aur strong.",
      "features": [
        "Spacious interior",
        "Zip closure",
        "Strong handles"
      ]
    },
    {
      "id": "p25",
      "name": "LCD Writing & Drawing Tablet",
      "category": "Kids & Toys",
      "price": 499,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/drawing.jpg",
      "placeholder": true,
      "desc": "Bachon ke liye paper-free drawing pad. Likhein, mitayein, dobara banayein.",
      "features": [
        "Erasable LCD screen",
        "Includes stylus",
        "Saves paper",
        "Perfect for kids"
      ]
    },
    {
      "id": "p26",
      "name": "Digital Kitchen Scale",
      "category": "Kitchen & Home",
      "price": 599,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/scale.jpg",
      "placeholder": true,
      "desc": "Cooking aur baking mein sahi wazan. Compact aur accurate.",
      "features": [
        "Accurate digital display",
        "Tare function",
        "Compact design"
      ]
    },
    {
      "id": "p27",
      "name": "Non-Stick Frying Pan",
      "category": "Kitchen & Home",
      "price": 1199,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/pan.jpg",
      "placeholder": true,
      "desc": "Kam tel mein pakayein, saaf karna aasaan. Mazboot non-stick coating.",
      "features": [
        "Non-stick coating",
        "Heat-resistant handle",
        "Easy to clean"
      ]
    },
    {
      "id": "p28",
      "name": "Ankle Socks – Pack of 3",
      "category": "Bags & Fashion",
      "price": 249,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/socks.jpg",
      "placeholder": true,
      "desc": "Soft cotton ankle socks, roz ke istemal ke liye.",
      "features": [
        "Soft cotton",
        "Pack of 3",
        "Comfortable fit"
      ]
    },
    {
      "id": "p29",
      "name": "UNO Playing Cards",
      "category": "Kids & Toys",
      "price": 340,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/uno.jpg",
      "placeholder": true,
      "desc": "Family aur doston ke saath khelne ka classic card game.",
      "features": [
        "Classic UNO game",
        "Fun for all ages",
        "Portable"
      ]
    },
    {
      "id": "p30",
      "name": "3x3 Speed Cube",
      "category": "Kids & Toys",
      "price": 350,
      "oldPrice": 0,
      "badge": "",
      "inStock": true,
      "image": "images/cube.jpg",
      "placeholder": true,
      "desc": "Smooth turning speed cube — dimagh tez karne ka mazedar tareeqa.",
      "features": [
        "Smooth rotation",
        "Vivid stickers",
        "Great for beginners"
      ]
    }
  ]
};
