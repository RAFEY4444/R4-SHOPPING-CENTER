/* R4 SHOPPING STORE — real 3D hero (Three.js). Falls back to CSS ring if WebGL unavailable. */
(function(){
  try{
    var T=window.THREE, wrap=document.getElementById('ringWrap'), P=(window.R4_PRODUCTS||[]).slice(0,10);
    if(!T||!wrap||!P.length) return;
    var test=document.createElement('canvas'); if(!(test.getContext('webgl')||test.getContext('experimental-webgl'))) return;
    var LOW=!!window.R4_LOW;
    var renderer=new T.WebGLRenderer({antialias:!LOW,alpha:true,powerPreference:'high-performance'});
    renderer.setPixelRatio(LOW?1:Math.min(window.devicePixelRatio||1,1.5));
    renderer.outputEncoding=T.sRGBEncoding;
    var cv=renderer.domElement; cv.style.cssText='position:absolute;inset:0;width:100%;height:100%;display:block';
    wrap.style.position='relative'; wrap.appendChild(cv);
    var scene=new T.Scene(), cam=new T.PerspectiveCamera(38,1,.1,100); cam.position.set(0,.6,15);
    scene.add(new T.AmbientLight(0xffffff,.75));
    var key=new T.DirectionalLight(0xffffff,.9); key.position.set(3,6,8); scene.add(key);
    var r1=new T.PointLight(0xff1f2d,2.2,18); r1.position.set(-5,2,4); scene.add(r1);
    var r2=new T.PointLight(0xff3040,1.6,18); r2.position.set(5,-1,3); scene.add(r2);
    var group=new T.Group(); scene.add(group);
    var N=P.length, R=4.1, loader=new T.TextureLoader(), boxes=[];
    var edge=new T.MeshStandardMaterial({color:0xd10f1f,metalness:.7,roughness:.25,emissive:0x330005});
    P.forEach(function(p,i){
      var uri=(window.R4_HERO&&window.R4_HERO[p.id])||p.image;
      var tex=loader.load(uri,function(){ if(renderer) renderer.render(scene,cam) }); tex.encoding=T.sRGBEncoding; tex.anisotropy=8;
      var face=new T.MeshStandardMaterial({map:tex,roughness:.35,metalness:.05});
      var geo=new T.BoxGeometry(2.1,2.1,.22);
      var mesh=new T.Mesh(geo,[edge,edge,edge,edge,face,face]);
      var a=i/N*Math.PI*2; mesh.position.set(Math.sin(a)*R,0,Math.cos(a)*R); mesh.rotation.y=a; mesh.userData={id:p.id,a:a};
      // white backing frame glow
      var frame=new T.Mesh(new T.BoxGeometry(2.26,2.26,.16),new T.MeshBasicMaterial({color:0xc40e1c})); frame.position.z=0; mesh.add(frame); frame.renderOrder=-1;
      group.add(mesh); boxes.push(mesh);
    });
    // glowing floor ring
    var ring=new T.Mesh(new T.RingGeometry(R-.15,R+.15,96),new T.MeshBasicMaterial({color:0xff2d3d,transparent:true,opacity:.55,side:T.DoubleSide}));
    ring.rotation.x=-Math.PI/2; ring.position.y=-1.55; scene.add(ring);
    var ring2=ring.clone(); ring2.scale.set(1.12,1.12,1.12); ring2.material=ring.material.clone(); ring2.material.opacity=.2; scene.add(ring2);
    var disc=new T.Mesh(new T.CircleGeometry(R+.6,64),new T.MeshBasicMaterial({color:0xff1f2d,transparent:true,opacity:.08})); disc.rotation.x=-Math.PI/2; disc.position.y=-1.56; scene.add(disc);
    // embers
    var pc=LOW?0:110,pg=new T.BufferGeometry(),pp=new Float32Array(pc*3);
    for(var k=0;k<pc;k++){pp[k*3]=(Math.random()-.5)*16;pp[k*3+1]=(Math.random()-.5)*9;pp[k*3+2]=(Math.random()-.5)*10}
    pg.setAttribute('position',new T.BufferAttribute(pp,3));
    var pts=new T.Points(pg,new T.PointsMaterial({color:0xff4b57,size:.05,transparent:true,opacity:.8})); if(pc)scene.add(pts);

    function size(){var w=wrap.clientWidth,h=wrap.clientHeight;renderer.setSize(w,h,false);cam.aspect=w/h;cam.position.z=w<500?19:15;cam.updateProjectionMatrix()}
    size(); window.addEventListener('resize',size);
    var ang=0,vel=.004,drag=false,lx=0,moved=0,mx=0,my=0,t0=performance.now();
    wrap.addEventListener('pointerdown',function(e){drag=true;lx=e.clientX;moved=0});
    window.addEventListener('pointerup',function(){drag=false});
    window.addEventListener('pointermove',function(e){
      if(drag){var d=e.clientX-lx;lx=e.clientX;moved+=Math.abs(d);ang+=d*.008;vel=d*.0015}
      var r=wrap.getBoundingClientRect();mx=((e.clientX-r.left)/r.width-.5);my=((e.clientY-r.top)/r.height-.5)});
    var ray=new T.Raycaster(),m2=new T.Vector2();
    wrap.addEventListener('click',function(e){
      if(moved>6)return;var r=cv.getBoundingClientRect();m2.set(((e.clientX-r.left)/r.width)*2-1,-((e.clientY-r.top)/r.height)*2+1);
      ray.setFromCamera(m2,cam);var hit=ray.intersectObjects(boxes,true)[0];
      if(hit){var o=hit.object;while(o&&!o.userData.id)o=o.parent;if(o)document.dispatchEvent(new CustomEvent('r4open',{detail:o.userData.id}))}});
    var vis=true,hid=false;
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;if(vis&&!running)loop()}).observe(wrap);
    document.addEventListener('visibilitychange',function(){hid=document.hidden;if(!hid&&vis&&!running)loop()});
    var running=false;
    function loop(){
      if(!vis||hid){running=false;return}running=true;
      var t=(performance.now()-t0)/1000;
      if(!drag){ang+=vel;vel+=(.004-vel)*.04}
      group.rotation.y=ang;
      boxes.forEach(function(b,i){b.position.y=Math.sin(t*1.2+i*.9)*.14;
        b.rotation.y=b.userData.a; /* faces outward */});
      group.rotation.x=my*.25; cam.position.x+=(mx*1.6-cam.position.x)*.05; cam.position.y+=(.6-my*1.4-cam.position.y)*.05; cam.lookAt(0,0,0);
      ring.rotation.z=t*.1; pts.rotation.y=t*.03; r1.position.x=-5+Math.sin(t)*2; r2.position.y=-1+Math.cos(t*1.3)*2;
      renderer.render(scene,cam);requestAnimationFrame(loop)}
    loop();
    var cssRing=document.getElementById('ring'); if(cssRing)cssRing.style.display='none';
    var hint=document.querySelector('.ring-hint'); if(hint)hint.textContent='Drag to spin • tap a product';
  }catch(e){ /* keep CSS ring */ }
})();
