/* R4 SHOPPING STORE — storefront logic */
(function () {
  'use strict';
  var DEF = window.R4_DEFAULT, DATA = DEF;
  try {
    var local = JSON.parse(localStorage.getItem('r4_data') || 'null');
    if (local && local.updated > DEF.updated) DATA = local; // owner preview on same browser
  } catch (e) {}
  var S = DATA.settings;
  var ALL = DATA.products.filter(function (p) { return !p.hidden; });
  window.R4_PRODUCTS = ALL;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var money = function (n) { return S.currency + ' ' + Number(n || 0).toLocaleString('en-PK'); };
  var thumb = function (src) { return /^images\/[^\/]+\.jpg$/.test(src || '') ? src.replace('images/', 'images/t/') : src; };
  var LOW = (navigator.hardwareConcurrency || 8) <= 4 || innerWidth < 700 || /Android|iPhone|iPad/i.test(navigator.userAgent);
  window.R4_LOW = LOW;
  var byId = function (id) { return ALL.filter(function (p) { return p.id === id; })[0]; };
  var store = {
    get: function (k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ---------- static bits ---------- */
  var waLink = function (text) { return 'https://wa.me/' + S.whatsapp + (text ? '?text=' + encodeURIComponent(text) : ''); };
  document.title = S.storeName + ' — ' + S.tagline;
  $('#announce').textContent = S.announcement || '';
  if (!S.announcement) $('#announce').hidden = true;
  $('#tagline').textContent = S.tagline;
  ['heroWa', 'contactWa', 'floatWa'].forEach(function (id) { $('#' + id).href = waLink('Assalam o Alaikum! I want to know about your products.'); });
  $('#contactPhone').textContent = S.displayPhone;
  $('#stProducts').textContent = ALL.length;
  $('#year').textContent = new Date().getFullYear();

  /* ---------- toast ---------- */
  var tt;
  function toast(msg) { var t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('show'); }, 2200); }

  /* ---------- cart ---------- */
  var cart = store.get('r4_cart', []).filter(function (i) { return byId(i.id); });
  function saveCart() { store.set('r4_cart', cart); renderCart(); }
  function addToCart(id, qty) {
    var p = byId(id); if (!p || p.inStock === false) return;
    var it = cart.filter(function (i) { return i.id === id; })[0];
    if (it) it.qty += qty || 1; else cart.push({ id: id, qty: qty || 1 });
    saveCart();
    var b = $('#openCart'); b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump');
    toast('✓ Added to cart');
  }
  function totals() {
    var sub = cart.reduce(function (s, i) { return s + byId(i.id).price * i.qty; }, 0);
    var del = cart.length ? (S.freeDeliveryAbove > 0 && sub >= S.freeDeliveryAbove ? 0 : Number(S.delivery) || 0) : 0;
    return { sub: sub, del: del, tot: sub + del };
  }
  function renderCart() {
    var n = cart.reduce(function (s, i) { return s + i.qty; }, 0);
    $('#cartCount').textContent = n;
    var has = cart.length > 0;
    $('#cartEmpty').hidden = has; $('#checkout').hidden = !has; $('#cartFoot').hidden = !has;
    $('#cartItems').innerHTML = cart.map(function (i) {
      var p = byId(i.id);
      return '<div class="ci"><img decoding="async" src="' + esc(thumb(p.image)) + '" alt=""><div><h5>' + esc(p.name) + '</h5><div class="p">' + money(p.price * i.qty) + '</div>' +
        '<div class="qty"><button data-a="dec" data-id="' + p.id + '">−</button><span>' + i.qty + '</span><button data-a="inc" data-id="' + p.id + '">+</button></div></div>' +
        '<button class="rm" data-a="rm" data-id="' + p.id + '">Remove</button></div>';
    }).join('');
    var t = totals();
    $('#sSub').textContent = money(t.sub);
    $('#sDel').textContent = t.del ? money(t.del) : 'FREE';
    $('#sTot').textContent = money(t.tot);
  }
  $('#cartItems').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-a]'); if (!b) return;
    var it = cart.filter(function (i) { return i.id === b.dataset.id; })[0]; if (!it) return;
    if (b.dataset.a === 'inc') it.qty++;
    else if (b.dataset.a === 'dec') it.qty = Math.max(1, it.qty - 1);
    else cart = cart.filter(function (i) { return i !== it; });
    saveCart();
  });
  $('#clearCart').onclick = function () { cart = []; saveCart(); };
  function openCart() { $('#cartOverlay').hidden = false; document.body.style.overflow = 'hidden'; renderCart(); }
  function closeCart() { $('#cartOverlay').hidden = true; document.body.style.overflow = ''; }
  $('#openCart').onclick = openCart; $('#closeCart').onclick = closeCart; $('#shopNow').onclick = closeCart;
  $('#cartOverlay').addEventListener('mousedown', function (e) { if (e.target.id === 'cartOverlay') closeCart(); });

  /* customer details are remembered on their device */
  var form = $('#checkout');
  var saved = store.get('r4_customer', {});
  ['name', 'phone', 'city', 'address', 'note'].forEach(function (k) { if (saved[k]) form.elements[k].value = saved[k]; });
  form.addEventListener('input', function (e) {
    e.target.classList.remove('bad');
    var c = {}; ['name', 'phone', 'city', 'address', 'note'].forEach(function (k) { c[k] = form.elements[k].value; });
    store.set('r4_customer', c);
  });
  $('#placeOrder').onclick = function () {
    var ok = true, c = {};
    ['name', 'phone', 'city', 'address', 'note'].forEach(function (k) {
      var el = form.elements[k]; c[k] = el.value.trim();
      if (el.required && !c[k]) { el.classList.add('bad'); ok = false; }
    });
    if (c.phone && c.phone.replace(/\D/g, '').length < 10) { form.elements.phone.classList.add('bad'); ok = false; }
    if (!ok) { toast('Please fill your delivery details'); form.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
    var t = totals(), id = 'R4-' + Date.now().toString().slice(-6), when = new Date().toLocaleString('en-GB');
    var items = cart.map(function (i) { var p = byId(i.id); return { name: p.name, qty: i.qty, price: p.price }; });
    var lines = items.map(function (i, k) { return (k + 1) + '. ' + i.name + ' × ' + i.qty + ' = ' + money(i.price * i.qty); });
    var receipt = '🧾 *RECEIPT — ' + S.storeName + '*\nOrder ID: ' + id + '\nDate: ' + when + '\n\n' +
      '👤 *Customer*\nName: ' + c.name + '\nPhone: ' + c.phone + '\nCity: ' + c.city + '\nAddress: ' + c.address + (c.note ? '\nNote: ' + c.note : '') +
      '\n\n📦 *Items*\n' + lines.join('\n') + '\n\nSubtotal: ' + money(t.sub) + '\nDelivery: ' + (t.del ? money(t.del) : 'FREE') + '\n*TOTAL: ' + money(t.tot) + '*\nPayment: Cash on Delivery';
    var order = { id: id, date: new Date().toISOString(), customer: c, items: items, total: t.tot, status: 'pending' };
    var history = store.get('r4_orders', []); history.unshift(order); store.set('r4_orders', history.slice(0, 50));
    // receipt screen
    $('#rId').textContent = id; $('#rDate').textContent = when;
    $('#rCust').innerHTML = '<b>' + esc(c.name) + '</b><br>' + esc(c.phone) + '<br>' + esc(c.city) + ' — ' + esc(c.address) + (c.note ? '<br><i>' + esc(c.note) + '</i>' : '');
    $('#rItems').innerHTML = items.map(function (i) { return '<div class="rl"><span>' + esc(i.name) + ' × ' + i.qty + '</span><b>' + money(i.price * i.qty) + '</b></div>'; }).join('') +
      '<div class="rl"><span>Subtotal</span><b>' + money(t.sub) + '</b></div><div class="rl"><span>Delivery</span><b>' + (t.del ? money(t.del) : 'FREE') + '</b></div><div class="rl tot"><span>TOTAL (Cash on Delivery)</span><b>' + money(t.tot) + '</b></div>';
    $('#rStatus').textContent = 'Please choose an option below'; $('#rStatus').className = 'rstat';
    $('#done').hidden = false;
    var send = function (status, head, icon) {
      order.status = status; var h = store.get('r4_orders', []); if (h[0] && h[0].id === id) { h[0].status = status; store.set('r4_orders', h); }
      var m = icon + ' *' + head + '*\n' + (status === 'confirmed' ? '' : 'Order ID: ' + id + '\nCustomer: ' + c.name + ' (' + c.phone + ')\n\n') + (status === 'confirmed' ? receipt + '\n\n— Sent from website. Please reply to this customer to confirm delivery.' : '(Details of this order are in the receipt sent earlier)');
      $('#rStatus').textContent = icon + ' ' + head; $('#rStatus').className = 'rstat ' + status;
      window.open(waLink(m), '_blank');
      if (status === 'confirmed') { cart = []; saveCart(); }
    };
    $('#actConfirm').onclick = function () { send('confirmed', 'ORDER CONFIRMED — ' + id, '✅'); };
    $('#actCancel').onclick = function () { send('cancelled', 'ORDER CANCELLED — ' + id, '❌'); };
    $('#actNo').onclick = function () { send('declined', 'NOT INTERESTED — ' + id + ' (customer does not want this order)', '🚫'); };
    $('#actPrint').onclick = function () { window.print(); };
    var img = null;
    var makeImg = function (cb) { if (img) return cb(img); drawReceipt({ id: id, when: when, c: c, items: items, t: t, status: order.status }, function (b) { img = b; cb(b); }); };
    $('#actImg').onclick = function () { makeImg(function (b) { var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'R4-receipt-' + id + '.png'; document.body.appendChild(a); a.click(); a.remove(); toast('📸 Receipt image saved'); }); };
    var sh = $('#actShare');
    try { var tf = new File([new Blob([''])], 't.png', { type: 'image/png' }); sh.hidden = !(navigator.canShare && navigator.canShare({ files: [tf] })); } catch (e) { sh.hidden = true; }
    sh.onclick = function () { makeImg(function (b) { navigator.share({ files: [new File([b], 'R4-receipt-' + id + '.png', { type: 'image/png' })], title: 'Receipt ' + id }).catch(function () {}); }); };
  };

  /* ---------- receipt as PNG image ---------- */
  function drawReceipt(o, cb) {
    var W = 900, pad = 56, rows = o.items.length, H = 760 + rows * 64 + (o.c.note ? 40 : 0);
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var x = cv.getContext('2d');
    var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#0b0b10'); g.addColorStop(1, '#1a0508'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    var rg = x.createLinearGradient(0, 0, W, 0); rg.addColorStop(0, '#ff5a5f'); rg.addColorStop(1, '#b3001b'); x.fillStyle = rg; x.fillRect(0, 0, W, 14);
    var T = function (t, px, py, size, w, col, al) { x.font = w + ' ' + size + 'px Manrope, Arial, sans-serif'; x.fillStyle = col; x.textAlign = al || 'left'; x.fillText(t, px, py); };
    var fit = function (t, max, size, w) { x.font = w + ' ' + size + 'px Manrope, Arial'; while (x.measureText(t).width > max && t.length > 4) t = t.slice(0, -2); return t; };
    T(S.storeName.toUpperCase(), W / 2, 90, 34, 800, '#ffffff', 'center');
    T('ORDER RECEIPT', W / 2, 130, 20, 700, '#ff4b57', 'center');
    x.strokeStyle = 'rgba(255,255,255,.18)'; x.setLineDash([8, 8]); x.beginPath(); x.moveTo(pad, 160); x.lineTo(W - pad, 160); x.stroke(); x.setLineDash([]);
    T('Order ID', pad, 205, 20, 600, '#a9a49a'); T(o.id, W - pad, 205, 26, 800, '#ffffff', 'right');
    T('Date', pad, 245, 20, 600, '#a9a49a'); T(o.when, W - pad, 245, 22, 700, '#ffffff', 'right');
    var y = 305; T('DELIVER TO', pad, y, 16, 800, '#ff4b57'); y += 36;
    T(fit(o.c.name, W - pad * 2, 26, 800), pad, y, 26, 800, '#fff'); y += 34;
    T(o.c.phone, pad, y, 22, 600, '#ddd'); y += 32;
    T(fit(o.c.city + ' — ' + o.c.address, W - pad * 2, 22, 600), pad, y, 22, 600, '#ddd'); y += 32;
    if (o.c.note) { T(fit('Note: ' + o.c.note, W - pad * 2, 20, 500), pad, y, 20, 500, '#a9a49a'); y += 32; }
    y += 24; T('ITEMS', pad, y, 16, 800, '#ff4b57'); y += 14;
    o.items.forEach(function (i) { y += 50; T(fit(i.name + ' × ' + i.qty, 560, 22, 600), pad, y, 22, 600, '#fff'); T(money(i.price * i.qty), W - pad, y, 22, 800, '#fff', 'right'); x.fillStyle = 'rgba(255,255,255,.07)'; x.fillRect(pad, y + 14, W - pad * 2, 1); });
    y += 56; T('Subtotal', pad, y, 21, 600, '#a9a49a'); T(money(o.t.sub), W - pad, y, 21, 700, '#fff', 'right');
    y += 38; T('Delivery', pad, y, 21, 600, '#a9a49a'); T(o.t.del ? money(o.t.del) : 'FREE', W - pad, y, 21, 700, '#fff', 'right');
    y += 22; x.fillStyle = rg; x.fillRect(pad, y, W - pad * 2, 3);
    y += 54; T('TOTAL (Cash on Delivery)', pad, y, 24, 800, '#fff'); T(money(o.t.tot), W - pad, y, 34, 800, '#ff4b57', 'right');
    y += 64; x.fillStyle = 'rgba(255,45,61,.14)'; x.fillRect(pad, y - 34, W - pad * 2, 60);
    T('WhatsApp: ' + S.displayPhone + '   •   Shop More • Pay Less', W / 2, y + 4, 20, 700, '#ff8088', 'center');
    y += 70; T('Thank you for shopping with us ♥', W / 2, y, 20, 600, '#a9a49a', 'center');
    cv.toBlob(cb, 'image/png');
  }

  /* ---------- grid ---------- */
  var cat = 'All', q = '', sort = 'def';
  var favs = store.get('r4_fav', []);
  function cats() { var s = ['All', '♥ Saved']; ALL.forEach(function (p) { if (p.category && s.indexOf(p.category) < 0) s.push(p.category); }); return s; }
  function renderChips() {
    $('#chips').innerHTML = cats().map(function (c) { return '<button class="chip' + (c === cat ? ' on' : '') + '" data-c="' + esc(c) + '">' + esc(c) + '</button>'; }).join('');
  }
  $('#chips').addEventListener('click', function (e) { var b = e.target.closest('.chip'); if (!b) return; cat = b.dataset.c; renderChips(); renderGrid(); });
  $('#search').addEventListener('input', function (e) { q = e.target.value.trim().toLowerCase(); renderGrid(); if (q) $('#shop').scrollIntoView({ behavior: 'smooth' }); });
  $('#sort').addEventListener('change', function (e) { sort = e.target.value; renderGrid(); });

  function renderGrid() {
    var list = ALL.filter(function (p) {
      return (cat === 'All' || (cat === '♥ Saved' ? favs.indexOf(p.id) > -1 : p.category === cat)) && (!q || (p.name + ' ' + p.category + ' ' + (p.desc || '')).toLowerCase().indexOf(q) > -1);
    });
    if (sort === 'low') list.sort(function (a, b) { return a.price - b.price; });
    if (sort === 'high') list.sort(function (a, b) { return b.price - a.price; });
    if (sort === 'az') list.sort(function (a, b) { return a.name.localeCompare(b.name); });
    $('#empty').hidden = list.length > 0;
    $('#grid').innerHTML = list.map(function (p) {
      var out = p.inStock === false;
      return '<article class="card" data-id="' + p.id + '">' +
        (out ? '<span class="badge out">Sold out</span>' : (p.badge ? '<span class="badge">' + esc(p.badge) + '</span>' : '')) +
        '<button class="fav' + (favs.indexOf(p.id) > -1 ? ' on' : '') + '" data-fav="' + p.id + '" aria-label="Save">♥</button><span class="view3d">3D VIEW</span>' + (p.placeholder ? '<span class="ph">Sample image</span>' : '') +
        '<div class="plate" data-open="' + p.id + '"><img loading="lazy" decoding="async" width="300" height="300" src="' + esc(thumb(p.image)) + '" alt="' + esc(p.name) + '"></div>' +
        '<div class="body"><div class="cat">' + esc(p.category) + '</div><h3>' + esc(p.name) + '</h3>' +
        '<div class="price-row"><span class="price">' + money(p.price) + '</span>' + (p.oldPrice > p.price ? '<span class="old">' + money(p.oldPrice) + '</span>' : '') + '</div>' +
        '<div class="card-actions"><button class="btn gold-btn" data-add="' + p.id + '"' + (out ? ' disabled' : '') + '>' + (out ? 'Sold out' : 'Add to Cart') + '</button>' +
        '<button class="icon-btn" data-open="' + p.id + '" aria-label="View details">👁</button></div></div></article>';
    }).join('');
    observe();
  }
  var grid = $('#grid');
  grid.addEventListener('click', function (e) {
    var f = e.target.closest('[data-fav]'); if (f) { var id = f.dataset.fav, k = favs.indexOf(id); if (k > -1) favs.splice(k, 1); else favs.push(id); store.set('r4_fav', favs); f.classList.toggle('on'); toast(k > -1 ? 'Removed from saved' : '♥ Saved'); return; }
    var a = e.target.closest('[data-add]'); if (a) { addToCart(a.dataset.add, 1); return; }
    var o = e.target.closest('[data-open]'); if (o) openModal(o.dataset.open);
  });
  /* 3D tilt (rAF-throttled, desktop only) */
  if (!LOW && !window.matchMedia('(hover:none)').matches) {
    var tc = null, tx = 0, ty = 0, tq = false;
    var paint = function () { tq = false; if (!tc) return; var r = tc.getBoundingClientRect(), x = (tx - r.left) / r.width, y = (ty - r.top) / r.height;
      tc.style.setProperty('--ry', ((x - .5) * 16).toFixed(1) + 'deg'); tc.style.setProperty('--rx', ((.5 - y) * 16).toFixed(1) + 'deg');
      tc.style.setProperty('--gx', (x * 100).toFixed(0) + '%'); tc.style.setProperty('--gy', (y * 100).toFixed(0) + '%'); };
    grid.addEventListener('mousemove', function (e) { var c = e.target.closest('.card'); if (!c) return; tc = c; tx = e.clientX; ty = e.clientY; if (!tq) { tq = true; requestAnimationFrame(paint); } }, { passive: true });
    grid.addEventListener('mouseout', function (e) { var c = e.target.closest('.card'); if (c && !c.contains(e.relatedTarget)) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); if (tc === c) tc = null; } });
  }

  /* ---------- product modal with 3D slab ---------- */
  var cur = null, qty = 1, rx = -8, ry = 24, auto = false, raf = null, drag = null;
  var slab = $('#slab');
  function applyRot() { slab.style.transform = 'rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)'; }
  function loop() { if (auto && !drag) { ry += .8; applyRot(); raf = requestAnimationFrame(loop); } else raf = null; }
  function openModal(id) {
    cur = byId(id); if (!cur) return; qty = 1; $('#mQty').textContent = 1;
    var layers = ''; for (var i = 1; i <= 7; i++) layers += '<div class="layer" style="transform:translateZ(' + (7 - i * 2) + 'px);filter:brightness(' + (0.7 + i * 0.04) + ')"></div>';
    slab.innerHTML = layers + '<div class="face front"><img src="' + esc(cur.image) + '" alt="' + esc(cur.name) + '"></div><div class="face back"><div>R4<small>SHOPPING STORE</small></div></div><div class="slab-shadow"></div>';
    rx = -8; ry = 24; auto = false; $('#spinBtn').classList.remove('on'); applyRot();
    $('#mCat').textContent = cur.category; $('#mName').textContent = cur.name; $('#mPrice').textContent = money(cur.price);
    $('#mOld').textContent = cur.oldPrice > cur.price ? money(cur.oldPrice) : ''; $('#mDesc').textContent = cur.desc || '';
    $('#mFeat').innerHTML = (cur.features || []).map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('');
    var out = cur.inStock === false; $('#mAdd').disabled = out; $('#mAdd').textContent = out ? 'Sold out' : 'Add to Cart';
    $('#modal').hidden = false; document.body.style.overflow = 'hidden';
    cancelAnimationFrame(raf); raf = null;
  }
  function closeModal() { $('#modal').hidden = true; document.body.style.overflow = ''; cancelAnimationFrame(raf); raf = null; }
  $('#closeModal').onclick = closeModal;
  $('#modal').addEventListener('mousedown', function (e) { if (e.target.id === 'modal') closeModal(); });
  $('#modal .qty').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; qty = Math.max(1, qty + Number(b.dataset.d)); $('#mQty').textContent = qty; });
  $('#mAdd').onclick = function () { addToCart(cur.id, qty); closeModal(); openCart(); };
  $('#mWa').onclick = function () { window.open(waLink('Assalam o Alaikum! I want to order:\n' + cur.name + ' × ' + qty + '\nPrice: ' + money(cur.price * qty) + '\n\nPlease confirm availability.'), '_blank'); };
  $('#spinBtn').onclick = function () { auto = !auto; this.classList.toggle('on', auto); if (auto && !raf) loop(); };
  $('#resetBtn').onclick = function () { rx = -8; ry = 24; applyRot(); };
  var stage = $('#stage');
  stage.addEventListener('pointerdown', function (e) { drag = { x: e.clientX, y: e.clientY }; stage.setPointerCapture(e.pointerId); });
  stage.addEventListener('pointermove', function (e) {
    if (!drag) return; ry += (e.clientX - drag.x) * .6; rx = Math.max(-60, Math.min(60, rx - (e.clientY - drag.y) * .5)); drag = { x: e.clientX, y: e.clientY }; applyRot();
  });
  ['pointerup', 'pointercancel'].forEach(function (ev) { stage.addEventListener(ev, function () { drag = null; }); });

  /* ---------- hero 3D ring ---------- */
  (function () {
    var ring = $('#ring'), items = ALL.slice(0, 10), n = items.length; if (!n) return;
    try { var gt = document.createElement('canvas'); if (window.THREE && (gt.getContext('webgl') || gt.getContext('experimental-webgl'))) return; } catch (e) {}
    ring.innerHTML = items.map(function (p, i) {
      return '<div class="ri" data-i="' + i + '"><img src="' + esc(thumb(p.image)) + '" alt="' + esc(p.name) + '"><span>' + esc(p.name) + '</span></div>';
    }).join('');
    var my = 0, ang = 0, vel = .22, dragging = false, lx = 0, moved = 0, cards = $$('.ri', ring);
    function size() { var w = $('#ringWrap').clientWidth, cw = cards[0].offsetWidth; var R = Math.max(150, (cw / 2) / Math.tan(Math.PI / n) * 1.12); return Math.min(R, w * .55); }
    var R = size();
    function layout() { cards.forEach(function (c, i) { c.style.transform = 'rotateY(' + (i * 360 / n) + 'deg) translateZ(' + R + 'px)'; }); }
    layout(); window.addEventListener('resize', function () { R = size(); layout(); });
    function tick() { if (!dragging) { ang += vel; vel += (.22 - vel) * .03; } ring.style.transform = 'rotateX(' + (-8 + my) + 'deg) rotateY(' + ang + 'deg)'; requestAnimationFrame(tick); }
    tick();
    var w = $('#ringWrap');
    $('.hero').addEventListener('mousemove', function (e) { var r = this.getBoundingClientRect(); my = ((e.clientY - r.top) / r.height - .5) * -18; });
    w.addEventListener('pointerdown', function (e) { dragging = true; lx = e.clientX; moved = 0; });
    window.addEventListener('pointermove', function (e) { if (!dragging) return; var d = e.clientX - lx; lx = e.clientX; moved += Math.abs(d); ang += d * .4; vel = d * .15; });
    window.addEventListener('pointerup', function () { dragging = false; });
    w.addEventListener('click', function (e) { var c = e.target.closest('.ri'); if (c && moved < 6) openModal(items[c.dataset.i].id); });
  })();

  /* ---------- reveal on scroll ---------- */
  var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { threshold: .08 }) : null;
  function observe() {
    $$('.reveal:not(.in)').forEach(function (el) { io ? io.observe(el) : el.classList.add('in'); });
    $$('.card:not(.reveal)').forEach(function (el, i) { el.classList.add('reveal'); el.style.transitionDelay = (i % 4) * 70 + 'ms'; io ? io.observe(el) : el.classList.add('in'); });
  }
  $('#doneClose').onclick = function () { $('#done').hidden = true; closeCart(); };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeModal(); closeCart(); } });

  document.addEventListener('r4open', function (e) { openModal(e.detail); });
  renderChips(); renderGrid(); renderCart(); observe();
})();

/* background: light embers + mouse spotlight (disabled on low-end devices) */
(function(){var c=document.getElementById('embers'),s=document.getElementById('spot');
if(window.R4_LOW||!c){c&&c.remove();s&&s.remove();return}
var x=c.getContext('2d'),W,H,ps=[],on=true,sp=document.getElementById('spot');
function rs(){W=c.width=innerWidth;H=c.height=innerHeight}rs();addEventListener('resize',rs);
for(var i=0;i<26;i++)ps.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.8+.6,v:Math.random()*.4+.12,a:Math.random()*.5+.25,d:Math.random()*6});
document.addEventListener('visibilitychange',function(){on=!document.hidden;if(on)f(0)});
function f(t){if(!on)return;x.clearRect(0,0,W,H);x.fillStyle='rgba(255,70,80,.7)';ps.forEach(function(p){p.y-=p.v;p.x+=Math.sin(t/1800+p.d)*.25;if(p.y<-5){p.y=H+5;p.x=Math.random()*W}
x.globalAlpha=p.a;x.fillRect(p.x,p.y,p.r*2,p.r*2)});x.globalAlpha=1;requestAnimationFrame(f)}
f(0);
var q=0,mx=0,my=0;addEventListener('mousemove',function(e){mx=e.clientX;my=e.clientY;if(!q){q=1;requestAnimationFrame(function(){q=0;sp.style.transform='translate('+mx+'px,'+my+'px)'})}},{passive:true});})();

/* ===== premium extras ===== */
(function(){
  var $=function(q){return document.querySelector(q)};
  // preloader
  var pre=$('#pre'); window.addEventListener('load',function(){setTimeout(function(){pre&&pre.classList.add('out');setTimeout(function(){pre&&pre.remove()},500)},400)});
  setTimeout(function(){pre&&pre.classList.add('out')},3500);
  // scroll progress + back to top
  var bar=$('#progress'),top=$('#toTop');
  var sq=0;addEventListener('scroll',function(){if(sq)return;sq=1;requestAnimationFrame(function(){sq=0;var h=document.documentElement,y=h.scrollTop,m=h.scrollHeight-h.clientHeight;bar.style.transform='scaleX('+(m>0?y/m:0)+')';top.classList.toggle('show',y>800)})},{passive:true});
  top.onclick=function(){scrollTo({top:0,behavior:'smooth'})};
  // countdown to midnight
  var cd=$('#cd');function tick(){var n=new Date(),e=new Date(n);e.setHours(24,0,0,0);var d=e-n,H=Math.floor(d/36e5),M=Math.floor(d%36e5/6e4),S=Math.floor(d%6e4/1e3);
    cd.innerHTML='<i>'+String(H).padStart(2,'0')+'</i>:<i>'+String(M).padStart(2,'0')+'</i>:<i>'+String(S).padStart(2,'0')+'</i>'}
  tick();setInterval(tick,1000);
  // FAQ
  document.querySelectorAll('.faq details').forEach(function(d){d.addEventListener('toggle',function(){if(d.open)document.querySelectorAll('.faq details').forEach(function(o){if(o!==d)o.open=false})})});
})();
